


<?php $__env->startSection('title'); ?>
    <h3>Category Edit</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="text-center d-flex justify-content-center">
  <main class="py-2 w-50 border bg-white text-center">
    <form method="POST" action="<?php echo e(route('category.update', $data->id)); ?>">
      <?php echo csrf_field(); ?>
      <div class="mb-3">
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
    <strong><?php echo e($message); ?></strong>
</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <input name="_method" type="hidden" value="PATCH">
        <label for="exampleInputEmail1" class="form-label">Category Name</label>
        <input name="name" value="<?php echo e($data->name); ?>" type="name" class="form-control" id="exampleInputname1" aria-describedby="nameHelp">
      </div>
      <button type="submit" class="btn btn-primary">Submit</button>
    </form>
  </main>

</div>
<?php $__env->stopSection(); ?>
</div>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\Laravel\laravel9stock2\resources\views/category/edit.blade.php ENDPATH**/ ?>