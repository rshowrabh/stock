


<?php $__env->startSection('title'); ?>
    <h3>Category</h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(session()->has('message')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('message')); ?>

    </div>
<?php endif; ?>
<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
    <strong><?php echo e($message); ?></strong>
</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<div class="text-center">
    <main class="py-2">
        <!-- Button trigger modal -->
  <a href="<?php echo e(route('category.create')); ?>"><button type="button" class="d-flex justify-content-left btn btn-primary">
    Add New
  </button></a>
        <div class="d-flex justify-content-center">
        <table class="table w-50 table-bordered">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Name</th>
                <th scope="col">Edit</th>
                <th scope="col">Delete</th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th scope="row"><?php echo e($data->id); ?></th>
                <td><?php echo e($data->name); ?></td>
                <td><a href="<?php echo e(route('category.edit', $data->id)); ?>"><button class="btn btn-secondary">Edit</button></a></td>
                <td>
                  <form method="post" action="<?php echo e(route('category.destroy', $data->id)); ?>">
                    <!-- here the '1' is the id of the post which you want to delete -->
                
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('DELETE')); ?>

                
                    <button onclick="return confirm('Are you sure?')" class="btn btn-danger" type="submit">Delete</button>
                </form>  
                </td>
                
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
            </tbody>
          </table>
        </div>
    </main>
    <?php echo e($datas->links("pagination::bootstrap-5")); ?>


</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\Laravel\laravel9stock2\resources\views/category/index.blade.php ENDPATH**/ ?>